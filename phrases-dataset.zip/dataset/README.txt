Phrase Suggestions dataset
release 0.1

Contents
--------

final_reviews.csv: The final review text for each participant when submitted.

by_suggestion.csv: All suggestions offered by the interface, including the number of words of that suggestion that were ultimately accepted and the (reconstructed) probability of generating that suggestion in the given context.

logs/*.jsonl: raw log files from the suggestion interface. Detailed documentation will be available in the next release.

dataset.py: code for parsing the raw log files into the CSVs given.
