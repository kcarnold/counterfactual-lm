import dateutil.parser
import json

def jsonl(fname):
    return (json.loads(line) for line in open(fname))

def get_words(sug):
    words = sug['one_word']['words'][:]
    if len(sug['continuation']):
        words.extend(sug['continuation'][0]['words'])
    return words

def get_final_text(log):
    for line in reversed(log):
        if line.get('name') == 'updateCompose':
            return line['curText']

def track_suggestions(log):
    '''
    Returns a list of suggestions and what happened to them.

    [{'context', 'words', 'num_accepted_words', 'appeared_at', 'visible_secs'}]
    '''
    first_timestamp = dateutil.parser.parse(log[0]['timestamp'])
    final_text = get_final_text(log)
    suggs = []
    cur_suggs = [None] * 4
    cur_text = ''
    for entry_idx, entry in enumerate(log):
        typ = entry.get('name')
        now = (dateutil.parser.parse(entry['timestamp']) - first_timestamp).total_seconds()
        if typ == 'updateCompose':
            cur_text = entry['curText']
        elif typ == 'showSuggestions':
            new_suggs = entry['suggestions']['next_word']
            for i in range(4):
                sug = new_suggs[i] if i < len(new_suggs) else None
                if cur_suggs[i] is not None:
                    old_sugg = cur_suggs[i]
                    # See if this was a phrase suggestion continuation
                    if sug is not None and get_words(sug)[:1] == old_sugg['words'][old_sugg['num_accepted_words']:][:1]:
                        # Don't overwrite.
                        continue
                    old_sugg['visible_secs'] = now - old_sugg['appeared_at']
                    suggs.append(old_sugg)
                    cur_suggs[i] = None
                if sug is None:
                    continue
                cur_suggs[i] = dict(pid=entry['participant_id'], context=cur_text, words=get_words(sug), num_accepted_words=0, slot=i, appeared_at=now, visible_secs=None)
        elif typ == 'insertedSuggestion':
            prev_sugg = cur_suggs[entry['slot']]
            if prev_sugg is None or prev_sugg['words'][prev_sugg['num_accepted_words']] !=entry['toInsert']:
                print("alert: mismatched toInsert", entry['toInsert'])
            prev_sugg['num_accepted_words'] += 1
    for i in range(3):
        sug = cur_suggs[i]
        if sug is not None:
            sug['visible_secs'] = now - sug['appeared_at']
            suggs.append(sug)
    return [sugg for sugg in suggs if final_text.startswith(sugg['context']) and (sugg['num_accepted_words'] > 0 or sugg['visible_secs'] > .3)]

all_logs = {}
import glob
for fn in glob.glob('logs/*.jsonl'):
    log = list(jsonl(fn))
    all_logs[log[0]['participant_id']] = log
suggs = {part_id: track_suggestions(log) for part_id, log in all_logs.items()}
final_reviews = {part_id: get_final_text(log) for part_id, log in all_logs.items()}
